//------------------------------------------------------------------------------
//	My Customised Multi-Player
//------------------------------------------------------------------------------

// ...
_LOG("Customised Multi-Player...\n");
_LOG("\n");

// ...
var theSpan     = 0.02; // in seconds.
var theSpeed    = 0.10;
var theSubCount = 5;

// ...
var theDoc = NTApp.newDocument("Customised Multi-Player");

// ...
var thePlayer = theDoc.createPlayerMulti(theSubCount);
thePlayer.setSpan (theSpan);
thePlayer.setTime (theSpan / 2);
thePlayer.setSpeed(theSpeed);

// ...
for(var i = 0; i < theSubCount; ++i) {
	var aSubPlayer = thePlayer.getSubPlayerAtIndex(i);
	aSubPlayer.setSpeed   (0.5 * (i + 1) + 0.05 * i * i);
	aSubPlayer.setVolume  (-2 * i);
//	aSubPlayer.setSpeedWow(0.05 * i);
}

// ...
//thePlayer.play();

