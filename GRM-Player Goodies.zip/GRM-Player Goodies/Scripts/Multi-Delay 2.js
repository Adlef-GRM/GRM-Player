//------------------------------------------------------------------------------
//	Try Multi-Delay
//------------------------------------------------------------------------------

// ...
_LOG("Try Multi-Delay...\n");
_LOG("\n");

// ...
var theSubCount = 5;
var theSpan     = 4.0; // in seconds.

// ...
var theDoc = NTApp.newDocument("Multi-Delay 2");

// ...
var theSequence = theDoc.createSequenceWithSound("../Sounds/Bienvenue.aiff");
theSequence.setSelectionAll();

// ...
var thePlayer = theSequence.createAndAttachPlayerMulti(theSubCount);
thePlayer.setTime(theSpan / 2);
thePlayer.setSpan(theSpan);

// ...
for(var i = 0; i < theSubCount; ++i) {
	var aPlayer = thePlayer.getSubPlayerAtIndex(i);
	var aCoeff  = pow(i / (theSubCount - 1), 2); // in [0,1].
	aPlayer.setRelaTime(0.95 - 0.9 * aCoeff);
	aPlayer.setVolume  (-36 * aCoeff);
}

// ...
//thePlayer.play();

