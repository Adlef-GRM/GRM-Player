//------------------------------------------------------------------------------
//	Try Funny Bong
//------------------------------------------------------------------------------

// ...
_LOG("Try Funny Bong...\n");
_LOG("\n");

// ...
var theDoc = NTApp.newDocument("Funny Bong");
theDoc.setPreferedNextObjectID(100);

// ...
var theSequence = theDoc.createSequenceWithSound("../Sounds/Henry.aiff");
//theSequence.setSelectionAll();

// ...
for(var i = 0; i < 10; ++i) {
	var aPlayer = theSequence.createAndAttachPlayer();
	var aSpeed  = 0.5 + i / 10;
	var aTime   = 20 - 10 * aSpeed;
	aPlayer.setTime  (aTime);
	aPlayer.setSpeed (aSpeed);
	aPlayer.setVolume(-2 * i);
}

// ...
//theSequence.play();

