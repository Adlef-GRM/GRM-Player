//------------------------------------------------------------------------------
//	Try Multi-Delay
//------------------------------------------------------------------------------

// ...
_LOG("Try Multi-Delay...\n");
_LOG("\n");

// ...
var theSubCount = 4;
var theSpan     = 0.5; // in seconds.

// ...
var theDoc = NTApp.newDocument("Multi-Delay 1");

// ...
var theSequence = theDoc.createSequenceWithSound("../Sounds/Bienvenue.aiff");
theSequence.setSelectionAll();

// ...
var thePlayer = theSequence.createAndAttachPlayerMulti(theSubCount);
thePlayer.setTime(theSpan / 2);
thePlayer.setSpan(theSpan);

// ...
for(var i = 0; i < theSubCount; ++i) {
	var aPlayer = thePlayer.getSubPlayerAtIndex(i);
	aPlayer.setRelaTime(0.95 - 0.2 * i);
	aPlayer.setVolume  (-8 * i);
}

// ...
//thePlayer.play();

