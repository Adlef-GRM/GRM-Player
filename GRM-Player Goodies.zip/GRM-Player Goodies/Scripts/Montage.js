//------------------------------------------------------------------------------
//	Try Montage
//------------------------------------------------------------------------------

// ...
_LOG("Try Montage...\n");
_LOG("\n");

// ...
var theDoc = NTApp.newDocument("Montage");

// Source A.
var theSequenceA = theDoc.createSequenceWithSound("../Sounds/Bienvenue.aiff");
var theTrackA    = theSequenceA.getSubTrackAtIndex(0);

// Source B.
var theSequenceB = theDoc.createSequenceWithSound("../Sounds/Merle.wav");
var theTrackB    = theSequenceB.getSubTrackAtIndex(0);

// Result.
var theSequenceR = theDoc.createSequence();
var theTrackR    = theSequenceR.getSubTrackAtIndex(0);
theSequenceR.createAndAttachPlayer();

// Montage.
theTrackR.plus(theTrackB.part(5, 8)).plus(theTrackA.part(1, 4)).plus(theTrackB.part(5, 10));

// Cleanup.
theSequenceB.destroy();
theSequenceA.destroy();

