//------------------------------------------------------------------------------
//	Try Flanger
//------------------------------------------------------------------------------

// ...
_LOG("Try Flanger...\n");
_LOG("\n");

// ...
var theSubCount = 3;
var theSpan     = 0.02; // in seconds.

// ...
var theDoc = NTApp.newDocument("Flanger");

// ...
var theSequence = theDoc.createSequenceWithSound("../Sounds/Jaojoby.aiff");
//theSequence.setSelectionAll();

// ...
var thePlayer = theSequence.createAndAttachPlayerMulti(theSubCount);
thePlayer.setTime(theSpan / 2);
thePlayer.setSpan(theSpan);

// ...
for(var i = 0; i < theSubCount; ++i) {
	var aPlayer = thePlayer.getSubPlayerAtIndex(i);
	aPlayer.setRelaTime(0.5);
//	aPlayer.setVolume  ( -2 * i);
	aPlayer.setSpeedWow(0.05 * i);
}

// ...
//thePlayer.play();

