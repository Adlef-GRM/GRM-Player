//------------------------------------------------------------------------------
//	Harmonizer
//------------------------------------------------------------------------------

// ...
_LOG("Harmonizer...\n");
_LOG("\n");

// ...
var theSubCount = 3;
var theSpan     = 0.0085; // in seconds.

// ...
var theDoc = NTApp.newDocument("Harmonizer");

// ...
var theSequence = theDoc.createSequenceWithSound("../Sounds/Bienvenue.aiff");
theSequence.setSelectionAll();
theSequence.createAndAttachPlayer();

// ...
var thePlayer = theSequence.createAndAttachPlayerMulti(theSubCount);
thePlayer.setSpan(theSpan);
thePlayer.setSpeed(1);

// ...
var theSubs = thePlayer.getSubPlayers();
theSubs[0].setSpeed(0.55); theSubs[0].setVolume( 0);
theSubs[1].setSpeed(0.83); theSubs[1].setVolume(-3);
theSubs[2].setSpeed(1.10); theSubs[2].setVolume(-6);

// ...
//thePlayer.play();

